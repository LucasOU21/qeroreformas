import{i}from"./index.B1fp56SV.js";i();
