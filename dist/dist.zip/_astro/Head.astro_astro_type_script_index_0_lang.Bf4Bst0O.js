import"./MainLayout.astro_astro_type_script_index_0_lang.bRPwqdfh.js";
